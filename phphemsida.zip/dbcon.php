<?php

$servername = "localhost";
$username = "faha0011";
$password = "Htcsmart971221";
$dbname = "faha0011";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} 

?>