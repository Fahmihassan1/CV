<?php
        //php inloggs funktion som ansluter till min databas. Ifall jag skriver fel namn eller lösen så kommer man inte vidare i hemsidan. skriver man rätt namn och lösenord så går man vidare.

    if(isset ($_POST['loginBtn'])){
     
     $errors = array();
     
     if(isset($_POST['username']) && $_POST['username'] !=""){
         echo $_POST['username'];
     } else {
         $errors[] = "no Username";
     }
 } 


     if (isset($_POST['password'])  && $_POST['password'] !=""){
         echo $_POST['password'];
     } else {
              $errors[] = "no password";
     }

     if (empty($errors)){
         
        $username = $_POST['username']; 
        $password = $_POST['password']; 
         
        // ansluta till databasen 
         
$host = "localhost";
$usernameDB = "faha0011";
$passwordDB = "Htcsmart971221";
$database = "faha0011";

$mysqli = new mysqli($host, $usernameDB, $passwordDB, $database);
 
         //check connection
  if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
     exit();
       }
  //select tabellen user  
  if ($result = $mysqli->query("SELECT * FROM user WHERE username = '{$username}' AND password = '{$password}'")) {
      
      if($result->num_rows == 1){
          // tar datan från rad 1
          // ifall den hittar användare så skickas man vidare till menysidan som är bilar.php
          echo "found user";
          header('Location:bilar.php');
      } 
          
      
   
      $result->close();
}

      
      $mysqli->close();
     
     }

?>

<html>


<head>
    
    <title> inlogg </title>
      <link rel="stylesheet" type="text/css" href="stylee.css">
    </head>
                    <!-- ett formulär där man ska skriva in namn och lösenord för inloggningen.--> 
<body>
  <form action="index.php" method="post">
    <p> skriv in namn och lösenord. </p>  
  <input type="TEXT" name="username" value="" placeholder="Username" >
  <input type="PASSWORD" name="password" value="" placeholder="password" >
  <input type="submit" name="loginBtn" value="login">      
 
       </form>
                                
  </body>

</html>